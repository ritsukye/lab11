package trees;

public class TreeException extends ???
{
	public TreeException(String s)
	{
		// Pass s into a superclass ctor.
	}
}
